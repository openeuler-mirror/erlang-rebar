-module(app_src_script).

-compile(export_all).

test() ->
    ok.
