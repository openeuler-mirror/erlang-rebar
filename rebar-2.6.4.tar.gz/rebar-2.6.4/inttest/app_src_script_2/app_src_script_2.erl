-module(app_src_script_2).

-compile(export_all).

test() ->
    ok.
