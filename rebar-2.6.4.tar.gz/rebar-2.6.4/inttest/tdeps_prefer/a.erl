-module({{module}}).

-include_lib("b/include/b.hrl").
-include_lib("c/include/c.hrl").
